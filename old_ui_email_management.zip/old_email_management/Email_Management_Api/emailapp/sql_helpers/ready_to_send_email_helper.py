from .database import Database


class ReadyToSendEmailsHelper(Database):

    def __init__(self, *args):
        super(ReadyToSendEmailsHelper, self).__init__(*args)

    def add_ready_to_emails(self, email_address, campaign_id, html_template, subject, status):
        data = {"email_address": email_address, "campaign_id": campaign_id, "html_template": html_template,
                "subject": subject, "status": status}
        self.insert("ready_to_send_emails", data)

        # query = "INSERT INTO ready_to_send_emails(email_address, campaign_id, html_template, subject, status) " \
        #         "VALUE (%s, %s, %s, %s, %s)"
        #
        # self.add(query, (email_address, campaign_id, html_template, subject, status))

    def get_all_emails_to_queued(self, campaign_id):
        fields = ('id', 'email_address', 'email_address', 'campaign_id', 'template_html', 'subject',
                  'status', 'list_segment_id', 'created_on')
        where = ('status=%s or status=%s ', ['READY_TO_SEND', 'QUEUED'])
        return self.getAll("ready_to_send_emails", fields, where)

        # query = "Select * from ready_to_send_emails " \
        #         "where (status='READY_TO_SEND' or status='QUEUED') and campaign_id=%s;" % campaign_id
        # return self.fetch_all(query)

    def get_total_email_in_segment(self, list_id):
        fields = ('id', 'email', 'list_id', 'user_id', 'created_on')
        where = ('list_id=%s', [list_id])
        return self.getAll("list_segments", fields, where)

        # query = "Select * from list_segments where list_id=%s" % list_id
        # return self.fetch_all(query)

    def get_error_send_emails(self, campaign_id):
        fields = ('id', 'email_address', 'email_address', 'campaign_id', 'template_html', 'subject',
                  'status', 'list_segment_id', 'created_on')
        where = ('campaign_id=%s and status=%s ', [campaign_id, 'SENT'])
        return self.getAll("ready_to_send_emails", fields, where)

        # query = "Select * from ready_to_send_emails " \
        #         "where status='SENT' and campaign_id=%s;" % campaign_id
        # return self.fetch_all(query)

    def get_error_emails(self, campaign_id):
        fields = ('id', 'email_address', 'email_address', 'campaign_id', 'template_html', 'subject',
                  'status', 'list_segment_id', 'created_on')
        where = ('campaign_id=%s and status=%s ', [campaign_id, 'ERROR'])
        return self.getAll("ready_to_send_emails", fields, where)

        # query = "Select * from ready_to_send_emails " \
        #         "where status='ERROR' and campaign_id=%s;" % campaign_id
        # return self.fetch_all(query)

    def get_send_emails(self, campaign_id):
        fields = ('id', 'email_address', 'email_address', 'campaign_id', 'template_html', 'subject',
                  'status', 'list_segment_id', 'created_on')
        where = ('campaign_id=%s and status=%s ', [campaign_id, 'SENT'])
        return self.getAll("ready_to_send_emails", fields, where)

        # query = "Select * from ready_to_send_emails " \
        #         "where status='SENT' and campaign_id=%s;" % campaign_id
        # return self.fetch_all(query)

    def get_unsubscribe_emails(self, campaign_id):
        fields = ('id', 'email_address')
        where = ('campaign_id=%s and status=%s ', [campaign_id, 'UNSUBSCRIBE'])
        return self.getAll("ready_to_send_emails", fields, where)
