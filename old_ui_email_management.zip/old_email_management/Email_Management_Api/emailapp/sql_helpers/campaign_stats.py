from .database import Database


class CampaignStatsHelper(Database):

    def __init__(self, *args):
        super(CampaignStatsHelper, self).__init__(*args)

    def add_campaign_open_stats(self, campaign_id, segment_id, template_id,
                                open, click, full_url, IPAddress):
        data = {'campaign_id': campaign_id, 'segment_id': segment_id, 'template_id': template_id,
                'open': open, 'click': click, 'url': full_url, 'IPAddress': IPAddress}
        self.insert("campaign_stats", data)

    def add_campaign_click_stats(self, campaign_id, segment_id, template_id,
                                 open, click, full_url):
        data = {'campaign_id': campaign_id, 'segment_id': segment_id, 'template_id': template_id,
                'open': open, 'click': click, 'url': full_url}
        self.insert("campaign_stats", data)

    def get_campaign_stats(self, campaign_id):
        query = "SELECT cs.id, cs.campaign_id, cs.segment_id, cs.template_id, " \
                "cs.open, cs.click, cs.url, cs.created_on," \
                " ls.email, l.id, l.list_name, t.name, cs.IPAddress FROM campaign_stats cs" \
                " inner join list_segments ls on ls.id=cs.segment_id" \
                " inner join list l on l.id=ls.list_id" \
                " inner join templates t on t.id=cs.template_id" \
                " WHERE campaign_id=%s"

        return self.query(query, [campaign_id])

    def get_unique_open(self, campaign_id):
        query = "SELECT segment_id, campaign_id, open from campaign_stats" \
                " group by segment_id, campaign_id, open Having open=1 and campaign_id=%s "

        return self.query(query, [campaign_id])
