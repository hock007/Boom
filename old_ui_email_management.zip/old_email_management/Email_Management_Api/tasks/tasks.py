import mysql.connector
from celery import Celery
import logging
from conf.config import MYSQL_USER, MYSQL_PASS, MYSQL_HOST, DBNAME, \
    CONNECT_TIMEOUT, CELERY_BROKER_URL, CELERY_RESULT_BACKEND, \
    USE_AWS_EMAIL_SERVER, EMAIL_OPEN_URL, EMAIL_CLICK_URL, \
    APP_ROOT, APP_STATIC, LIMIT, EMAIL_UNSUBSCRIBE
from smtp_email import SmtpEmail
from ses_email import Email
import traceback
import mysql.connector
import os
from string import Template
from sql_helpers import campaign_helper, lists, templates, email_result, \
    ready_to_send_email_helper, emails_unsubscribe
import urllib
from tracking.email_tracking import EmailTracking
import pytracking
from pytracking.html import adapt_html
from datetime import datetime
from datetime import timedelta


logging.basicConfig(format='%(asctime)s %(message)s', level=logging.DEBUG)


CELERYBEAT_SCHEDULE = {
    "runs-every-35-seconds": {
        "task": "process_emails",
        "schedule": 35.0,
        "args": (),
    },
    "runs-every-65-seconds": {
        "task": "process_ab_campaign_emails",
        "schedule": 65.0,
        "args": (),
    },
    "run-send-email-40-seconds": {
        "task": "send_emails",
        "schedule": 40.0,
        "args": (),
    },
    "runs-every-50-seconds": {
        "task": "mark_campaigns_processed",
        "schedule": 50.0,
        "args": (),
     },
 }

my_sql_cursor = mysql.connector.connect(user=MYSQL_USER,
                                        password=MYSQL_PASS,
                                        host=MYSQL_HOST,
                                        database=DBNAME,
                                        connect_timeout=CONNECT_TIMEOUT)

my_sql_cursor.autocommit = False

app = Celery('tasks')

app.conf.update(
    result_expires=60,
    task_acks_late=True,
    broker_url=CELERY_BROKER_URL,
    result_backend=CELERY_RESULT_BACKEND
)

CELERY_ROUTES = {
    'tasks.send_email': {'queue': 'send_email'},
}


###############################################################################
#                                                                             #
#   app.config_from_object(CELERY_CONFIG)                                     #
#   run below statement                                                       #
#   celery - A tasks.app worker - B --loglevel = info                         #
#   celery -A tasks.app purge                                                 #
#   celery -A tasks.app worker -B --loglevel=info -Q default,send_email -c 10 #
#                                                                             #
###############################################################################

app.conf.beat_schedule.update(CELERYBEAT_SCHEDULE)

app.conf.task_default_queue = 'default'

app.conf.task_routes = CELERY_ROUTES


@app.task(name="mark_campaigns_processed")
def mark_campaigns_processed():

    campaign_obj = campaign_helper.CampaignHelper()
    list_obj = lists.Lists()
    email_result_obj = email_result.EmailResultHelper()
    ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper()

    try:
        campaigns = campaign_obj.get_email_configurations_processing(is_ab_campaign=False)
        my_sql_cursor.commit()

        for campaign in campaigns:
            campaign_id = campaign['id']
            is_ab_campaign = int.from_bytes(campaign['is_ab_campaign'], byteorder='big')

            logging.warning('Processing Campaign %s' % campaign_id)

            emails_result = email_result_obj.check_if_all_emails_processed_for_ab_campaign(campaign_id)
            ready_to_send_emails = ready_to_send_emails_obj.get_all_emails_by_AB_campaign(campaign_id)

            if len(emails_result) == len(ready_to_send_emails):
                campaign_obj. \
                         update_email_configration_status(campaign_id, 'PROCESSED')
            my_sql_cursor.commit()

    except Exception as e:
        my_sql_cursor.rollback()
        logging.warning('[celery app] :: mark_campaigns_processed() :: Got exception: %s' % e)
        logging.warning(traceback.format_exc())

    try:
        logging.warning('Processing AB campaigns...')
        campaigns = campaign_obj.\
            get_email_configurations_processing(is_ab_campaign=True)
        campaign_id = ''
        b_campaign = ''
        b_campaign_id = ''

        campaign_id = ''
        b_campaign = ''
        b_campaign_id = ''
        for campaign in campaigns:
            campaign_id = campaign['id']
            b_campaign = campaign_obj.get_campaign_by_parent_id(campaign_id)

        for campaign in b_campaign:
            b_campaign_id = campaign['id']

        emails_a_result = email_result_obj. \
            check_if_all_emails_processed_for_ab_campaign(campaign_id)

        emails_b_result = email_result_obj. \
            check_if_all_emails_processed_for_ab_campaign(b_campaign_id)

        ready_to_send_a_emails = ready_to_send_emails_obj. \
            get_all_emails_by_AB_campaign(campaign_id)
        ready_to_send_b_emails = ready_to_send_emails_obj. \
            get_all_emails_by_AB_campaign(b_campaign_id)

        if len(emails_a_result) == len(ready_to_send_a_emails) \
                and len(emails_b_result) == len(ready_to_send_b_emails):

            campaign_obj. \
                update_email_configration_status(campaign_id, 'PROCESSED')
            campaign_obj. \
                update_email_configration_status(b_campaign_id, 'PROCESSED')
        my_sql_cursor.commit()

    except Exception as e:
        my_sql_cursor.rollback()
        logging.warning('[celery app] :: mark_campaigns_processed() :: '
                        'Got exception: %s' % e)
        logging.warning(traceback.format_exc())


@app.task(name="process_emails")
def process_emails_campaigns():
    try:
        logging.warning('process_emails_campaigns')
        campaign_helper_obj = campaign_helper.CampaignHelper()

        list_obj = lists.Lists()

        ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper()

        emails_unsubscribe_helper_obj = emails_unsubscribe.EmailUnsubscribeHelper()

        campaigns = campaign_helper_obj.get_email_configurations()
        for email_config in campaigns:
            try:

                campaign_id = email_config['id']
                template_id = email_config['templates_id']
                if campaign_helper_obj.\
                        check_if_campaign_already_processing(campaign_id):
                    logging.warning('Already Processed # %s' % (str(campaign_id)))
                    continue

                list_id = email_config['list_id']

                users = list_obj.\
                    get_list_segment_by_listid(list_id)  # get segments on base of list id
                # Change status to PROCESSING
                processing_status = 'PROCESSING'
                campaign_helper_obj.\
                    update_email_configration_status(campaign_id, processing_status)

                template_html = build_template(template_id)
                subject = email_config['name']
                get_ready_to_send_emails = len(ready_to_send_emails_obj.get_all_emails_by_campaign(campaign_id))

                list_segments_emails = list_obj.get_segments_mails_by_campaing_id(campaign_id)
                list_segments_emails_list = []
                for get_list_segments in list_segments_emails:
                    list_segments_emails_list.append(get_list_segments)

                get_list_segments_emails = len(list_segments_emails_list)
                # get_list_segments_emails = len(list_obj.get_segments_mails_by_campaing_id(campaign_id))

                if template_html:
                    try:
                        for user in users:
                            last_one_hour_emails = ready_to_send_emails_obj.get_all_ready_to_send_emails_by_status()
                            one_hour_record_list = []
                            for emails_record in last_one_hour_emails:
                                one_hour_record_list.append(emails_record)
                            last_one_hour_emails_len = len(one_hour_record_list)
                            # last_one_hour_emails_len = len(
                            #     ready_to_send_emails_obj.get_all_ready_to_send_emails_by_status())

                            logging.warning('last_one_hour_emails %s' % last_one_hour_emails_len)

                            if last_one_hour_emails_len > LIMIT:
                                logging.warning('One hour limit crossed !')
                                break
                            else:

                                remaining_emails = LIMIT - last_one_hour_emails_len
                                logging.warning('remaining_emails %s' % remaining_emails)

                                ready_email_status = "READY_TO_SEND"
                                email_address = user['email']
                                list_segment_id = user['id']

                                email_schedule_for_sending = ready_to_send_emails_obj.\
                                    check_is_emails_records(email_address, campaign_id)

                                if not email_schedule_for_sending:

                                    if emails_unsubscribe_helper_obj.check_emails_record(email_address):
                                        ready_email_status = "UNSUBSCRIBE"
                                        ready_to_send_emails_obj. \
                                            add_ready_to_emails(email_address,
                                                                campaign_id,
                                                                template_html,
                                                                subject,
                                                                ready_email_status,
                                                                list_segment_id)
                                    else:

                                        ready_email_status = "READY_TO_SEND"

                                        ready_to_send_emails_obj.\
                                            add_ready_to_emails(email_address,
                                                                campaign_id,
                                                                template_html,
                                                                subject,
                                                                ready_email_status,
                                                                list_segment_id)
                            if get_ready_to_send_emails == get_list_segments_emails:
                                processing_status = 'QUEUED'
                                campaign_helper_obj.\
                                    update_email_configration_status(campaign_id,
                                                                     processing_status)

                    except Exception as e:
                        logging.warning('[Tasks] :: process_email() :: %s' % e)
                        logging.warning(traceback.format_exc())

                my_sql_cursor.commit()

            except Exception as e:
                my_sql_cursor.rollback()
                logging.warning('[Tasks] :: process_email() :: %s' % e)
                logging.warning(traceback.format_exc())
    except Exception as e:
        logging.warning(e)
        logging.warning(traceback.format_exc())


@app.task(name="process_ab_campaign_emails")
def process_emails_ab_campaigns():
    try:
        logging.warning('process AB campaign')

        campaign_helper_obj = campaign_helper.CampaignHelper()

        emails_unsubscribe_helper_obj = emails_unsubscribe.EmailUnsubscribeHelper()

        list_obj = lists.Lists()

        ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper()
        QUEUED_TIME = datetime.now()
        campaigns = campaign_helper_obj.get_ab_campaigns()

        for email_config in campaigns:
            try:
                campaign_id = email_config['id']
                list_id = email_config['list_id']
                templates_id = email_config['templates_id']
                subject = email_config['name']
                if campaign_helper_obj.\
                        check_if_campaign_already_processing(campaign_id):
                    logging.warning('Already Processed # %s' % (str(campaign_id)))
                    continue

                segments = list_obj.\
                    get_list_segment_by_listid(list_id)  # get segments on base of list id

                """
                Change status to PROCESSING
                """
                processing_status = 'PROCESSING'
                campaign_helper_obj.\
                    update_email_configration_status(campaign_id,
                                                     processing_status)

                template_html = build_template(templates_id)
                subject = subject  # get A

                if template_html:
                    try:
                        test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_id)
                        test_percentage = test_percentage_obj['test_percentage']

                        segment_list_len = len(segments)
                        if test_percentage:

                            test_percent = int(int(segment_list_len) * int(test_percentage))/100
                            campaign_first_half = int(test_percent)/2
                            segment_first_campaign = segments[:int(campaign_first_half)]

                            segment_second_campaign = segments[
                                                      int(campaign_first_half):(int(campaign_first_half) * 2)]

                            total_email_processed = len(segment_first_campaign) + len(segment_second_campaign)

                            logging.warning('total_email_processed %s' % total_email_processed)

                            last_one_hour_emails = ready_to_send_emails_obj.\
                                get_all_ready_to_send_emails_by_status()
                            one_hour_record_list = []
                            for emails_record in last_one_hour_emails:
                                one_hour_record_list.append(emails_record)

                            last_one_hour_emails_len = len(one_hour_record_list)

                            logging.warning('last_one_hour_emails_len %s' % last_one_hour_emails_len)
                            remaining_emails = LIMIT - last_one_hour_emails_len

                            logging.warning('Remaining AB emails %s' % remaining_emails)

                            if last_one_hour_emails_len > LIMIT:
                                logging.warning('AB Campaign One hour limit crossed !')
                                break
                            else:
                                if remaining_emails > total_email_processed:

                                    for segment_usr in segment_first_campaign:
                                        email_address = segment_usr['email']
                                        segment_id = segment_usr['id']

                                        email_schedule_for_sending = ready_to_send_emails_obj.\
                                            check_is_emails_records(email_address, campaign_id)
                                        if not email_schedule_for_sending:
                                            if emails_unsubscribe_helper_obj.check_emails_record(email_address):
                                                ready_email_status = "UNSUBSCRIBE"
                                                ready_to_send_emails_obj. \
                                                    add_ready_to_emails(email_address,
                                                                        campaign_id,
                                                                        template_html,
                                                                        subject,
                                                                        ready_email_status,
                                                                        segment_id)
                                            else:
                                                ready_email_status = "READY_TO_SEND"
                                                ready_to_send_emails_obj.add_ready_to_emails(email_address,
                                                                                             campaign_id,
                                                                                             template_html,
                                                                                             subject,
                                                                                             ready_email_status,
                                                                                             segment_id)

                                            processing_status = 'QUEUED'
                                            campaign_helper_obj.\
                                                update_email_configration_queued_time(campaign_id,
                                                                                      processing_status,
                                                                                      QUEUED_TIME)
                                        # break  # send only single email

                                    campaign_b = campaign_helper_obj.\
                                        get_campaign_by_parent_id(campaign_id)
                                    campaign_b_id = ''
                                    campaign_b_subject = ''
                                    for campaign in campaign_b:
                                        campaign_b_id = campaign['id']
                                        campaign_b_subject = campaign['name']

                                    processing_status = 'PROCESSING'
                                    campaign_helper_obj.\
                                        update_email_configration_status(campaign_b_id,
                                                                         processing_status)

                                    for segment_usr in segment_second_campaign:

                                        segment_id = segment_usr['id']
                                        email_address = segment_usr['email']
                                        email_schedule_for_sending = ready_to_send_emails_obj.\
                                            check_is_emails_records(email_address, campaign_b_id)
                                        if not email_schedule_for_sending:

                                            if emails_unsubscribe_helper_obj.check_emails_record(email_address):
                                                ready_email_status = "UNSUBSCRIBE"
                                                ready_to_send_emails_obj. \
                                                    add_ready_to_emails(email_address,
                                                                        campaign_id,
                                                                        template_html,
                                                                        campaign_b_subject,
                                                                        ready_email_status,
                                                                        segment_id)
                                            else:
                                                ready_email_status = "READY_TO_SEND"
                                                ready_to_send_emails_obj.add_ready_to_emails(email_address,
                                                                                             campaign_b_id,
                                                                                             template_html,
                                                                                             campaign_b_subject,
                                                                                             ready_email_status,
                                                                                             segment_id)

                                        processing_status = 'QUEUED'
                                        campaign_helper_obj.\
                                            update_email_configration_queued_time(campaign_b_id,
                                                                                  processing_status,
                                                                                  QUEUED_TIME)
                                        # break  # send only single email
                                else:
                                    logging.warning('total mails are more then remaining emails !')
                                    break
                    except Exception as e:
                        logging.warning('[Tasks] :: '
                                        'process_emails_ab_campaigns() :: %s' % e)
                        logging.warning(traceback.format_exc())

                my_sql_cursor.commit()
            except Exception as e:
                my_sql_cursor.rollback()
                logging.warning('[Tasks] :: process_emails_ab_campaigns() :: %s' % e)
                logging.warning(traceback.format_exc())
    except Exception as e:
        logging.warning(e)
        logging.warning(traceback.format_exc())


@app.task(name="send_emails")
def send_emails():
    try:
        ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper()

        ready_to_send_emails_records = ready_to_send_emails_obj.get_all_ready_to_send_emails()

        for emails_records in ready_to_send_emails_records:
            try:
                email_address = emails_records['email_address']
                campaign_id = emails_records['campaign_id']

                if not ready_to_send_emails_obj.\
                        check_if_email_already_queued(email_address,
                                                      campaign_id):
                    ready_to_send_emails_obj.\
                        update_ready_to_send_status(campaign_id,
                                                    email_address, "QUEUED")

                    template_html = emails_records['template_html']
                    subject = emails_records['subject']
                    segment_id = emails_records['list_segment_id']
                    list_id = emails_records['list_id']
                    template_id = emails_records['templates_id']

                    # call send email
                    send_email.delay(template_html, email_address,
                                     list_id, segment_id,
                                     template_id, campaign_id, subject)

                    my_sql_cursor.commit()
            except Exception as e:
                my_sql_cursor.rollback()
                logging.warning(e)
    except Exception as e:
        logging.warning(e)


def build_template(templateId):
    template_helper = templates.Templates()

    app_static_path = APP_STATIC

    file_path = '%s/%s' % (app_static_path, 'email_template')
    template_obj = template_helper.get_template_by_id(templateId)

    template_name = template_obj['path']
    template_path = file_path + template_name

    with open(r'%s' % template_path, 'r') as f:
        template_content = f.read()

    html_template = Template(template_content)

    template_vars_data = template_helper.get_template_vars_by_template_id(templateId)

    key_val = {}
    for vars_data in template_vars_data:
        template_key = vars_data['template_key']
        template_value = vars_data['template_value']
        if template_key not in key_val:
            key_val[template_key] = ""

        key_val[template_key] = template_value

    html = html_template.substitute(key_val)
    return html


@app.task(name="send_email")
def send_email(html, email_address, list_id, segment_id,
               template_id, campaign_id, subject):

    email_result_obj = email_result.EmailResultHelper()

    ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper()

    list_segment_id = segment_id
    try:
        email_address = email_address

        logging.warning('[celery email Address] %s' % email_address)

        # email_tracking_obj = EmailTracking()
        # open_url = email_tracking_obj.email_encoding(template_id, campaign_id, segment_id)

        configuration = pytracking.Configuration(
            base_open_tracking_url=EMAIL_OPEN_URL,
            base_click_tracking_url=EMAIL_CLICK_URL,
            include_webhook_url=False)

        html = adapt_html(html,
                          extra_metadata={"template_id": template_id,
                                          "segment_id": segment_id,
                                          "campaign_id": campaign_id},
                          click_tracking=True,
                          open_tracking=True,
                          configuration=configuration)

        unsubscribe_url = "%s/%s/%s/" % (EMAIL_UNSUBSCRIBE, segment_id, campaign_id)
        html = html.replace("EMAIL_UNSUBSCRIBE_URL", unsubscribe_url)

        if USE_AWS_EMAIL_SERVER:
            mail_obj = Email(email_address, subject, html)
            # mail_obj.send()
        else:
            # set up the SMTP server
            smtp_email_obj = SmtpEmail(email_address, subject, html)
            smtp_email_obj.send()

        logging.warning('mail is sent successfully')

        email_result_obj.create_email_result(campaign_id, list_id,
                                             list_segment_id, template_id,
                                             "SENT", "SUCCESS")

        ready_to_send_emails_obj.update_ready_to_send_status(campaign_id,
                                                             email_address,
                                                             "SENT")
        my_sql_cursor.commit()
        logging.warning('Mail is sent successfully')
    except Exception as e:
        my_sql_cursor.rollback()

        try:
            email_result_obj.create_email_result(campaign_id, list_id,
                                                 list_segment_id,
                                                 template_id,
                                                 "ERROR", "ERROR")
            ready_to_send_emails_obj.\
                update_ready_to_send_status(campaign_id,
                                            email_address, "ERROR")
            my_sql_cursor.commit()

        except:
            pass

        logging.warning('[Tasks] :: send_email() :: Got exception: %s' % e)
        logging.warning(traceback.format_exc())
