import os

# MySQL Credential

MYSQL_USER = 'root'

MYSQL_PASS = '123'

MYSQL_HOST = '127.0.0.1'
# MYSQL_HOST = '0.0.0.0'
# MYSQL_HOST = '192.168.1.29'

MYSQL_PORT = '3306'

# DBNAME = 'emailparser_db'
# DBNAME = 'email_management_db'
DBNAME = 'emails_db'

CONNECT_TIMEOUT = 10000

APP_ROOT = os.path.dirname(os.path.abspath(__file__))  # refers to application_top
APP_STATIC = os.path.join(APP_ROOT, 'static')


# SES Authentication

AWS_ACCESS_KEY = 'AKIAIKSD5U5GZV2DBK5Q-AAWA'

AWS_REGION = 'us-west-2'

AWS_FROM_ADDRESS = 'kgaurav.ameotech@gmail.com'

AWS_SECRET_KEY = 'JFtDnKeeCBFIIq8RdZPc+jSFt6Fw+DquY8eMQy5_erer3/'


# celery broker url and celery result backend

# CELERY_BROKER_URL = 'amqp://parm:parm@ameotech@localhost:5672/parmhost'
CELERY_BROKER_URL = 'amqp://jack:admin123@localhost:5672/jackhost'

CELERY_RESULT_BACKEND = 'rpc://localhost//'

USE_AWS_EMAIL_SERVER = False

# LOGIN_EMAIL = 'kgaurav.ameotech@gmail.com'
LOGIN_EMAIL = 'anaconda.wb@gmail.com'

# LOGIN_PASSWORD = 'GK@ameo121'
LOGIN_PASSWORD = 'ameo@anaconda'

BASE_URL = 'http://0.0.0.0:8000'


EMAIL_OPEN_URL = BASE_URL + '/e/o/' # Open Email handler

EMAIL_CLICK_URL = BASE_URL + '/e/c/'  # Click link handler

EMAIL_UNSUBSCRIBE = BASE_URL + '/unsubscribe'  # unsubscribe link handler

PYTRACKING_SECRET_KEY = b'Ym8UYSnPLenVI_7DW-mJF0IG9B9k9tiVaiUh9Aj9RRY='

AWS_EMAIL_SENDING_RATE_LIMIT = 10000

AWS_EMAIL_SENDING_RATE_TIME = 60

LIMIT = 100
