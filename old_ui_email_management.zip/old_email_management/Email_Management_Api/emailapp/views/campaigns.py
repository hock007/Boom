import traceback
import json
from struct import *
from emailapp.decorate import login_required
from emailapp.sql_helpers import templates, authenticate, user, lists, \
    campaign_helper, email_result, ready_to_send_email_helper, \
    campaign_stats, campaign_winning_combination, emails_unsubscribe
from emailapp import app, session, request, redirect, render_template, \
    bcrypt, jsonify
from conf.config import EMAIL_OPEN_URL, APP_ROOT, APP_STATIC
from datetime import datetime, timedelta

campaign_stats_helper = campaign_stats.CampaignStatsHelper()
template_helper = templates.Templates()
user_authenticate = authenticate.Authenticate()
campaign_helper_obj = campaign_helper.CampaignHelper()
email_result_helper = email_result.EmailResultHelper()
ready_to_send_email_helper_obj = ready_to_send_email_helper\
    .ReadyToSendEmailsHelper()
email_user = user.User()
list_helper = lists.Lists()
campaign_winning_helper = campaign_winning_combination.CampaignWinningHelper()
emails_unsubscribe_obj = emails_unsubscribe.EmailUnsubscribeHelper()


@login_required
def campaigns():
    email_campaigns = campaign_helper_obj\
        .get_all_non_ab_campaigns(request.user)
    context = dict()
    context['email_campaigns'] = email_campaigns
    return render_template('campaigns/campaigns.html', **context)


@login_required
def ab_campaigns():
    email_campaigns = campaign_helper_obj\
        .get_all_ab_campaigns(request.user)
    context = dict()
    context['email_campaigns'] = email_campaigns
    return render_template('campaigns/ab_campaigns.html', **context)


@login_required
def create_campaign():
    list_data = list_helper.get_list(request.user)
    lst_data = []
    path = APP_STATIC
    for item in list_data:
        count = list_helper.get_listsegment_count(item['id'])
        lst = {"id": item['id'], "name": item['list_name'], "count": count}
        lst_data.append(lst)
    template_data = template_helper.get_templates()

    try:
        if request.method == 'POST':
            list_id = request.form['list_id']
            templates_id = request.form['template_id']
            campaign_name = request.form['campaign_name']
            is_publish = request.form['is_publish']

            status = "ACTIVE"
            state = "DRAFT"
            if is_publish == "1":
                state = "PUBLISHED"

            campaign_helper_obj\
                .create_campaign(campaign_name, templates_id, status,
                                 request.user, state, list_id=list_id,
                                 percentage=None, is_ab_campaign=False,
                                 parent_campaign_id=None)

            return redirect("/campaigns/")

        context = {'list_data': lst_data, 'template_data': template_data, 'base_path': path}
        return render_template('campaigns/create_campaign.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def create_ab_campaigns():
    try:
        list_data = list_helper.get_list(request.user)
        lst_data = []
        for item in list_data:
            count = list_helper.get_listsegment_count(item['id'])
            lst = {"id": item['id'], "name": item['list_name'], "count": count}
            lst_data.append(lst)
        template_data = template_helper.get_templates()

        if request.method == 'POST':
            campaign_name = request.form['campaign_name']
            list_id_a = request.form['list_id_a']
            percentage = request.form['percentage']
            rate = request.form['rate']
            time_type = request.form['time_type']
            time_after = request.form['time_after']

            templates_id_a = request.form['template_id_a']
            templates_id_b = request.form['template_id_b']
            is_publish = request.form['is_publish']

            name_a = campaign_name + '-A'

            status = "ACTIVE"
            state = "DRAFT"

            if percentage == '':
                percentage = 50

            if is_publish == "1":
                state = "PUBLISHED"
            campaign_a_id = campaign_helper_obj \
                .create_campaign(name_a, templates_id_a, status,
                                 request.user, state, percentage=percentage,
                                 list_id=list_id_a, is_ab_campaign=True,
                                 parent_campaign_id=None)

            name_b = campaign_name + '-B'

            campaign_b_id = campaign_helper_obj \
                .create_campaign(name_b, templates_id_b, status,
                                 request.user, state, percentage=None,
                                 list_id=list_id_a, is_ab_campaign=True,
                                 parent_campaign_id=campaign_a_id)

            campaign_winning_helper.\
                create_campaign_winning_combination(campaign_a_id, rate,
                                                    time_after, time_type)

            return redirect("/campaigns/ab/")

        context = {'list_data': lst_data, 'template_data': template_data}
        return render_template('campaigns/create_ab_campaign.html', **context)

    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def delete_campaign(campaign_id):
    try:
        campaign = campaign_helper_obj\
            .delete_campaign(campaign_id, request.user)
        return redirect('/campaigns/')
    except Exception as exp:
        app.logger.warning(exp)
        app.loggerwarning(traceback.format_exc())


@login_required
def delete_campaign_ab(campaign_id):
    try:
        b_campagin__id = campaign_helper_obj.\
            get_campaign_by_parent_campaign_id(campaign_id)
        campaign_b_id = b_campagin__id['id']
        campaign_helper_obj.delete_campaign(campaign_id, request.user)
        campaign_helper_obj.delete_campaign(campaign_b_id, request.user)
        return redirect('/campaigns/ab/')
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def get_campaigns(campaign_id=None):
    context = dict()
    try:
        if not campaign_id:
            latest_campaign = campaign_helper_obj.get_latest_campaign()

        else:
            latest_campaign = campaign_helper_obj.get_campaign_by_id(campaign_id)

        sent_error_emails_len = 0
        error_emails_len = 0
        if latest_campaign:
            campaign_id = latest_campaign['id']
            campaign_name = latest_campaign['name']
            list_id = latest_campaign['list_id']
            # sent_error_emails = email_result_helper.get_email_results_by_campaign_id(campaign_id)
            sent_error_emails = ready_to_send_email_helper_obj.get_total_email_in_segment(list_id)

            unsubscribe = ready_to_send_email_helper_obj.get_unsubscribe_emails(campaign_id)
            unsubscribe_emails_len = len(unsubscribe)

            error_emails = ready_to_send_email_helper_obj.get_error_emails(campaign_id)

            send_emails = ready_to_send_email_helper_obj.get_send_emails(campaign_id)

            # tracking = campaign_stats_helper.get_campagin_click_stats(campaign_id)
            tracking = campaign_stats_helper.get_campaign_stats(campaign_id)

            tracking_list = []
            for tracking_value in tracking:
                tracking_list.append(tracking_value)

            tracking_len = len(tracking_list)
            unique_open = campaign_stats_helper.get_unique_open(campaign_id)

            unique_open_list = []
            for unique_open_value in unique_open:
                unique_open_list.append(unique_open_value)

            unique_open_len = len(unique_open_list)

            sent_error_emails_len = len(sent_error_emails)
            error_emails_len = len(error_emails)
            send_emails_len = len(send_emails)

        email_results = email_result_helper\
            .get_email_results_by_campaign_id(campaign_id)

        email_results_list = []
        for email_result_value in email_results:
            email_results_list.append(email_result_value)

        context = {"campaign_id": campaign_id, "campaign_name": campaign_name,
                   "sent_error_emails_len": sent_error_emails_len,
                   "unsubscribe_emails_len": unsubscribe_emails_len,
                   "tracking": tracking_list, "tracking_len": tracking_len,
                   "error_emails_len": error_emails_len,
                   "unique_open": unique_open_len,
                   "send_emails_len": send_emails_len,
                   "email_results": email_results_list}
        return render_template('campaigns/email_graph.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())
        return render_template('campaigns/email_graph.html', **context)


@login_required
def get_campaign_graph_data(campaign_id):
    queued_len = 0
    ready_to_send_len = 0
    latest_campaign = None
    context = dict()
    unsubscribe_emails = 0
    if campaign_id == 0:
        latest_campaign = campaign_helper_obj.get_latest_campaign()
    else:
        latest_campaign = campaign_helper_obj.get_campaign_by_id(campaign_id)

    if latest_campaign:

        campaign_id = latest_campaign['id']

        list_id = latest_campaign['list_id']
        ab_campaign = campaign_helper_obj.check_is_ab_campaign(campaign_id)
        is_ab_campaign = ab_campaign[0]['is_ab_campaign']
        is_ab_campaign_value = int.from_bytes(is_ab_campaign, byteorder='big')

        if is_ab_campaign_value == 0:  # code for non ab campaigns
            total_emails = ready_to_send_email_helper_obj.get_total_email_in_segment(list_id)

            sent_emails = ready_to_send_email_helper_obj.get_error_send_emails(campaign_id)

            error_emails = ready_to_send_email_helper_obj.get_error_emails(campaign_id)

            unsubscribe_emails = ready_to_send_email_helper_obj.get_unsubscribe_emails(campaign_id)

            sent_emails_len = len(sent_emails)
            unsubscribe_emails_len = len(unsubscribe_emails)
            error_emails_len = len(error_emails)
            total_emails_len = len(total_emails)

            context = {"sent_emails": sent_emails_len,
                       "unsubscribe_emails": unsubscribe_emails_len,
                       "error_emails": error_emails_len,
                       "total_emails": total_emails_len}

        else:
            segments = list_helper.get_list_segment_by_listid(list_id)  # get segments on base of list id
            segment_list = []
            for segment_user in segments:
                segment_list.append(segment_user)

            test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_id)
            test_percentage = test_percentage_obj['test_percentage']
            segment_list_len = len(segment_list)
            total_emails = 0
            if test_percentage:
                test_percent = int(int(segment_list_len) * int(test_percentage)) / 100
                campaign_first_half = int(test_percent) / 2
                total_emails = int(campaign_first_half)
                segment_first_campaign = segment_list[:int(campaign_first_half)]
                unsubscribe_email_count = 0
                for email in segment_first_campaign:
                    email_address = email['email']
                    if emails_unsubscribe_obj.check_unsubscribe_emails(email_address):
                        unsubscribe_email_count += 1
                unsubscribe_emails = unsubscribe_email_count

            else:
                camaign_id_by_percent = campaign_helper_obj.get_campaign_by_parent_id(campaign_id)
                campaign_ids = camaign_id_by_percent[0]['parent_campaign_id']
                test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_ids)
                test_percentage = test_percentage_obj['test_percentage']
                if test_percentage:
                    test_percent = int(int(segment_list_len) * int(test_percentage)) / 100

                    campaign_first_half = int(int(test_percent) / 2)

                    campaign_second_half = segment_list[
                                           int(campaign_first_half):(int(campaign_first_half) * 2)]
                    total_emails = len(campaign_second_half)
                    unsubscribe_email_count = 0
                    for email in campaign_second_half:
                        email_address = email['email']
                        if emails_unsubscribe_obj.check_unsubscribe_emails(email_address):
                            unsubscribe_email_count += 1
                    unsubscribe_emails = unsubscribe_email_count

            sent_emails = ready_to_send_email_helper_obj.get_error_send_emails(campaign_id)

            error_emails = ready_to_send_email_helper_obj.get_error_emails(campaign_id)

            sent_emails_len = len(sent_emails)
            error_emails_len = len(error_emails)
            unsubscribe_emails_len = unsubscribe_emails
            total_emails_len = total_emails

            context = {"sent_emails": sent_emails_len,
                       "unsubscribe_emails": unsubscribe_emails_len,
                       "error_emails": error_emails_len,
                       "total_emails": total_emails_len}

        return jsonify(context)


@login_required
def mark_campaign_as_published():
    if request.method == "POST":
        toggle_status = request.form.get('data')
        campaign_id = request.form.get('id')
        if toggle_status == 'true':
            status = 'PUBLISHED'
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_id)
        else:
            status = 'DRAFT'
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_id)
        return ""


@login_required
def mark_ab_campaign_as_published():
    if request.method == "POST":
        toggle_status = request.form.get('data')
        campaign_a_id = request.form.get('id')
        campaign_b = campaign_helper_obj.get_campaign_id_by_parent_id(campaign_a_id)
        campaign_b_id = campaign_b[0]['id']

        if toggle_status == 'true':
            status = 'PUBLISHED'
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_a_id)
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_b_id)
        else:
            status = 'DRAFT'
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_a_id)
            campaign_helper_obj.update_campagin_state_by_id(status,
                                                            campaign_b_id)
        return ""


def get_campaign_context(latest_campaign):
    sent_error_emails_len = 0
    error_emails_len = 0
    unsubscribe_emails_len = 0
    context = None

    if latest_campaign:
        campaign_id = latest_campaign['id']  # id of A part
        campaign_name = latest_campaign['name']
        list_id = latest_campaign['list_id']

        segments = list_helper.get_list_segment_by_listid(list_id)  # get segments on base of list id
        segment_list = []
        for segment_user in segments:
            segment_list.append(segment_user)

        test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_id)
        test_percentage = test_percentage_obj['test_percentage']

        segment_list_len = len(segment_list)
        if test_percentage:

            test_percent = int(int(segment_list_len) * int(test_percentage)) / 100
            campaign_first_half = int(test_percent) / 2
            segment_first_campaign = segment_list[:int(campaign_first_half)]
            count = 0
            for email in segment_first_campaign:
                email_address = email['email']
                if emails_unsubscribe_obj.check_unsubscribe_emails(email_address):
                    count += 1
            unsubscribe_emails_len = count
            sent_error_emails_len = int(campaign_first_half)

        else:

            camaign_id_by_percent = campaign_helper_obj.get_campaign_by_parent_id(campaign_id)
            campaign_ids = camaign_id_by_percent[0]['parent_campaign_id']
            test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_ids)
            test_percentage = test_percentage_obj['test_percentage']
            if test_percentage:
                test_percent = int(int(segment_list_len) * int(test_percentage)) / 100

                campaign_first_half = int(int(test_percent) / 2)

                campaign_second_half = segment_list[
                                       int(campaign_first_half):(int(campaign_first_half) * 2)]
                count = 0
                for email in campaign_second_half:
                    email_address = email['email']
                    if emails_unsubscribe_obj.check_unsubscribe_emails(email_address):
                        count += 1
                unsubscribe_emails_len = count

                sent_error_emails_len = len(campaign_second_half)

        error_emails = ready_to_send_email_helper_obj.get_error_emails(campaign_id)
        send_emails = ready_to_send_email_helper_obj.get_send_emails(campaign_id)

        tracking = campaign_stats_helper.get_campaign_stats(campaign_id)

        tracking_list = []
        for tracking_value in tracking:
            tracking_list.append(tracking_value)

        tracking_len = len(tracking_list)

        error_emails_len = len(error_emails)
        send_emails_len = len(send_emails)

        unique_open_tuple = campaign_stats_helper.get_unique_open(campaign_id)

        unique_open_tuple_list = []
        for unique_open_tuple_value in unique_open_tuple:
            unique_open_tuple_list.append(unique_open_tuple_value)

        unique_open = 0
        if unique_open_tuple_list:
            unique_open = len(unique_open_tuple_list)

        email_results = email_result_helper \
            .get_email_results_by_campaign_id(int(campaign_id))

        email_results_list = []
        for email_result_value in email_results:
            email_results_list.append(email_result_value)

        context = {"campaign_id": campaign_id,
                   "campaign_name": campaign_name,
                   "sent_error_emails_len": sent_error_emails_len,
                   "unsubscribe_emails_len": unsubscribe_emails_len,
                   "tracking": tracking_list, "tracking_len": tracking_len,
                   "error_emails_len": error_emails_len,
                   "send_emails_len": send_emails_len,
                   "email_results": email_results_list,
                   "unique_open": unique_open}
    return context


@login_required
def get_ab_campaign_dashboard(campaign_id=None):
    context = dict()

    try:
        unique_open_a = 0
        unique_open_b = 0
        if not campaign_id:
            latest_campaign = campaign_helper_obj.get_latest_campaign()
        else:
            latest_campaign = campaign_helper_obj.get_campaign_by_id(campaign_id)
        if latest_campaign:
            context['campaign_a'] = get_campaign_context(latest_campaign)
            campaign_id = latest_campaign['id']
            unique_open_tuple = campaign_stats_helper.get_unique_open(campaign_id)

            unique_open_tuple_list = []
            for unique_open_tuple_value in unique_open_tuple:
                unique_open_tuple_list.append(unique_open_tuple_value)

            if unique_open_tuple_list:
                unique_open_a = len(unique_open_tuple_list)
            parent_campaign = campaign_helper_obj. \
                get_campaign_by_parent_campaign_id(campaign_id)

            if parent_campaign:
                context['campaign_b'] = get_campaign_context(parent_campaign)
                parent_campaign_id = parent_campaign['id']
                unique_open_tuple = campaign_stats_helper.get_unique_open(parent_campaign_id)

                unique_open_tuple_list = []
                for unique_open_tuple_value in unique_open_tuple:
                    unique_open_tuple_list.append(unique_open_tuple_value)

                if unique_open_tuple_list:
                    unique_open_b = len(unique_open_tuple_list)

            queued_time = campaign_helper_obj.get_queued_time(campaign_id)
            if queued_time:
                queue_time = queued_time['queued_time']
                current_time = datetime.now()
                winning_combination = campaign_winning_helper.get_all_combinations(campaign_id)
                winning_type = winning_combination['rate']
                winning_time = winning_combination['time_after']

                winning_day_hours = winning_combination['time_type']
                if winning_day_hours == 'days':
                    wining_time = queue_time + timedelta(days=int(winning_time))
                else:
                    wining_time = queue_time + timedelta(hours=int(winning_time))

                if current_time > wining_time:

                    if unique_open_a > unique_open_b:
                        context['campaign_a_winner'] = 'Campaign A is winner'
                    elif unique_open_a < unique_open_b:
                        context['campaign_b_winner'] = 'campaign B is winner'
                    else:
                        context['campaign_tie'] = 'Both campaign result are equal'
                else:
                    context['campaign_time'] = 'Campaign result in under process'
                    pass
        return render_template('campaigns/ab_campaign_dashboard.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        return render_template('campaigns/ab_campaign_dashboard.html', **context)


@login_required
def edit_campaign(campaign_id):

    campaign = campaign_helper_obj.get_campaign_by_id(campaign_id)
    campaign_name = campaign['name']
    list_data = list_helper.get_list(request.user)
    lst_data = []
    for item in list_data:
        count = list_helper.get_listsegment_count(item['id'])
        lst = {"id": item['id'], "name": item['list_name'], "count": count}
        lst_data.append(lst)
    template_data = template_helper.get_templates()
    try:
        if request.method == 'POST':
            list_id = request.form['list_id']
            campaign_name = request.form['campaign_name']
            state = "PUBLISHED"

            campaign_helper_obj.update_campaign(list_id, campaign_name, state, campaign_id)

            return redirect("/campaigns/")

        context = {'list_data': lst_data, 'template_data': template_data, 'campaign_name': campaign_name}
        return render_template('campaigns/edit_campaign.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def edit_ab_campaign(campaign_id):
    campaign = campaign_helper_obj.get_campaign_by_id(campaign_id)

    campaign_list = campaign['name'].split('-A')
    campaign_name = campaign_list[0]
    test_percentage = campaign['test_percentage']
    campaign_a_id = campaign['id']
    template_id = campaign['templates_id']
    campaign_b = campaign_helper_obj.get_campaign_id_by_parent_id(campaign_a_id)
    campaign_b_id = campaign_b[0]['id']
    campaign_b_templates_id = campaign_b[0]['templates_id']

    winning = campaign_winning_helper.get_all_combinations(campaign_id)
    list_data = list_helper.get_list(request.user)

    lst_data = []
    for item in list_data:
        count = list_helper.get_listsegment_count(item['id'])
        lst = {"id": item['id'], "name": item['list_name'], "count": count}
        lst_data.append(lst)
    template_a = template_helper.get_template_by_id(template_id)
    template_b = template_helper.get_template_by_id(campaign_b_templates_id)
    template_data = template_helper.get_templates()
    context = {'list_data': lst_data, 'template_data': template_data,
               'campaign_name': campaign_name, 'test_percentage': test_percentage,
               'winning': winning, 'template_a': template_a, 'template_b': template_b}

    try:
        if request.method == 'POST':
            campaign_name = request.form['campaign_name']
            list_id_a = request.form['list_id_a']
            percentage = request.form['percentage']
            rate = request.form['rate']
            time_type = request.form['time_type']
            time_after = request.form['time_after']
            templates_id_a = request.form['template_id_a']
            templates_id_b = request.form['template_id_b']

            state = "PUBLISHED"
            if percentage == '':
                percentage = 50
            name_a = campaign_name + '-A'

            campaign_helper_obj.update_ab_campaign(name_a,
                                                   templates_id_a,
                                                   list_id_a,
                                                   state,
                                                   campaign_id=campaign_a_id,
                                                   percentage=percentage)

            name_b = campaign_name + '-B'
            campaign_helper_obj.update_ab_campaign(name_b,
                                                   templates_id_b, list_id_a,
                                                   state,
                                                   campaign_id=campaign_b_id,
                                                   percentage='')

            campaign_winning_helper. \
                update_campaign_winning_combination(rate,
                                                    time_after,
                                                    time_type,
                                                    campaign_a_id)
            return redirect('/campaigns/ab/')

        return render_template('campaigns/edit_ab_campaign.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())
