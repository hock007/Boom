import traceback
# from emailapp.helpers.sqlhelper import *
from emailapp.decorate import login_required
from emailapp.sql_helpers import templates, authenticate, user, lists
from emailapp import app, session, request, redirect, render_template
import webbrowser
from flask import url_for


template_helper = templates.Templates()
user_authenticate = authenticate.Authenticate()
email_user = user.User()
list_helper = lists.Lists()


@login_required
def create_segment():
    try:
        if request.method == 'POST':
            listname = request.form['list']
            first = request.form['first']
            from_first = int(first)-1
            last = request.form['last']
            list_id = list_helper.create_list(listname, request.user)

            data = email_user.get_email_user()
            if first and last:
                dal = data[int(from_first):int(last)]
                for filter in dal:
                    filter_data = filter['email']
                    list_helper.add_list_by_id(filter_data, list_id)

                    # insert_list_segments()
                return redirect('/segments/')
            else:
                email = request.form.getlist('email')
                for record in email:
                    # insert_list_segments(record, list_id)
                    list_helper.add_list_by_id(record, list_id)
        context = {'data': email_user.get_email_user()}
        return render_template('segments/create_segments.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def get_list_segments():
    try:
        list_data = list_helper.get_list(request.user)
        lst_data = []
        for item in list_data:
            count = list_helper.get_listsegment_count(item['id'])
            lst = {"id": item['id'], "name": item['list_name'], "count": count}
            lst_data.append(lst)
        context = {'data': lst_data}
        return render_template('segments/list_segments.html', **context)
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def list_segment(id):
    segment = list_helper.get_list_by_id(id, request.user)
    name = segment['list_name']
    id = segment['id']
    context = {"data": list_helper.get_list_segment_by_listid(id),
               "segment_name": name, "segment_id": id}
    return render_template('segments/show_list_segment.html', **context)


@login_required
def delete_segment(id):
    try:
        list_helper.delete_segments(id)
        list_helper.delete_listsegment(id)
        return redirect('/segments/')
    except Exception as exp:
        app.logger.warning(exp)
        app.logger.warning(traceback.format_exc())


@login_required
def segment_name_update(id):
    if request.method == 'POST':
        name = request.form['name']
        list_helper.update_segment_name_by_id(name, id)
        return redirect('/segments/')


@login_required
def list_segment(id):
    segment = list_helper.get_list_by_id(id, request.user)
    name = segment['list_name']
    id = segment['id']
    context = {"data": list_helper.get_list_segment_by_listid(id),
               "segment_name": name, "segment_id": id}
    return render_template('segments/show_list_segment.html', **context)


@login_required
def template():
    template_id = request.args.get("id")
    template = template_helper.get_template_by_id(template_id)
    temp = template['id']
    return render_template(temp)


@login_required
def show_segment(id):
    segment = list_helper.get_list_by_id(id, request.user)
    name = segment['list_name']
    id = segment['id']
    data = list_helper.get_list_segment_by_listid(id)
    if request.method == 'POST':
        first = request.form['first']
        from_first = int(first) - 1
        last = request.form['last']
        data = email_user.get_email_user()

        if first and last:
            dal = data[int(from_first):int(last)]

            mails = []
            for filter in dal:
                filter_data = filter['email']
                emails = list_helper.check_exist_emails(filter_data, id)

                if emails:
                    app.logger.info(emails)

                else:
                    list_helper.add_list_by_id(filter_data, id)

            if mails:
                context = {'data': email_user.get_email_user(),
                           "segment_name": name, "segment_id": id,
                           'message': mails}
                return render_template('segments/segment.html', **context)
                # return "mails are already exists"
            else:
                return redirect('/segments/')
    context = {"data": data, 'users': email_user.get_email_user(),
               "segment_name": name, "segment_id": id}
    return render_template('segments/segment.html', **context)
